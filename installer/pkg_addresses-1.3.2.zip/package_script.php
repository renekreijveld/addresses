<?php

/**
 * @package     Com_addresses
 * @version     1.3.1
 * @copyright   Copyright (C) 2025. All rights reserved.
 * @license     GNU General Public License version 3 or later; see LICENSE.txt
 * @author      René Kreijveld <email@renekreijveld.nl> - https://renekreijveld.nl
 */

define('MODIFIED', 1);
define('NOT_MODIFIED', 2);

// No direct access
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Installer\Installer;

return new class () implements InstallerScriptInterface {

    private string $minimumJoomla = '5.2.0';
    private string $minimumPhp    = '8.3.0';
    private $logfile = JPATH_ADMINISTRATOR . '/logs/package_script.log';

    public function install(InstallerAdapter $adapter): bool
    {
        $this->log("running install");

        return true;
    }

    public function update(InstallerAdapter $adapter): bool
    {
        $this->log("running update");

        return true;
    }

    public function uninstall(InstallerAdapter $adapter): bool
    {
        $this->log("running uninstall");

        return true;
    }

    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        $this->log("running preflight");

        if (version_compare(PHP_VERSION, $this->minimumPhp, '<')) {
            Factory::getApplication()->enqueueMessage(sprintf(Text::_('JLIB_INSTALLER_MINIMUM_PHP'), $this->minimumPhp), 'error');
            return false;
        }

        if (version_compare(JVERSION, $this->minimumJoomla, '<')) {
            Factory::getApplication()->enqueueMessage(sprintf(Text::_('JLIB_INSTALLER_MINIMUM_JOOMLA'), $this->minimumJoomla), 'error');
            return false;
        }

        return true;
    }

    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        $this->log("running postflight");

        if ($type === 'install' || $type === 'discover_install') {
            // Process init sql file
            $this->log("running addressesInit");
            $this->addressesInit();
        }

        return true;
    }

    /**
     * Initializes the Addresses component.
     *
     * This method processes the initial SQL file to set up the database structure
     * for the Addresses component using the Joomla Installer.
     *
     * @return void
     */
    private function addressesInit(): void
    {
        $installer = new Installer();
        $xmlNode   = new \SimpleXMLElement('<sql><file driver="mysql" charset="utf8">' . JPATH_ROOT . '/administrator/components/com_addresses/sql/init.mysql.utf8.sql</file></sql>');
        $installer->parseSQLFiles($xmlNode);
    }

    /**
     * Logs a message to the package log file.
     *
     * This method writes a log entry with the current date and time,
     * prefixed with "Addresses Package: ", to the package log file.
     *
     * @param string $message The message to log.
     *
     * @return void
     */
    private function log($message): void
    {
        error_log(date("Y-m-d H:i:s ") . "Addresses Package: $message\n", 3, $this->logfile);
    }

};

